package com.eggiverse.app;

import android.app.Application;

public class EggiverseApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
